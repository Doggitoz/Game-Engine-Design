
int main()
{
    float interval = 0.03f;
    float time = Time();
    Start();
    scene->Update();
    while (true) {
        
    }
}